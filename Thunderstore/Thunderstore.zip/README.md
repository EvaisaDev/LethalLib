# LethalLib  
**A library for adding new content to Lethal Company, mainly for personal use.**
  
Currently includes: 
- Custom Scrap Item API
- Custom Shop Item API
- Custom Enemy API (Untested)
- Network Prefab API

# Recent Changes 
   
- Added custom info command support for shop items.
- Fixed item price system.
- Fixed buy sound on custom items.