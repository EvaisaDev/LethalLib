# LethalLib  
**A library for adding new content to Lethal Comany, mainly for personal use.**
  
Currently includes: 
- Custom Scrap Item API
- Custom Shop Item API
- Custom Enemy API (Untested)
- Network Prefab API

# Latest Changes  
   
- Added API for shop items.  
- Fixed some of the hooks which were preventing the player from loading into the game.  