# LethalLib  
**A library for adding new content to Lethal Company, mainly for personal use.**
  
Currently includes: 
- Custom Scrap Item API
- Custom Shop Item API
- Custom Enemy API
- Network Prefab API

# Recent Changes 
   
- Fixed issues with enemy API  
	- Bestiary now works  
	- Log entries are now correctly received after scanning.  