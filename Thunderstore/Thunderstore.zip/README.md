# LethalLib  
**A library for adding new content to Lethal Comany, mainly for personal use.**
  
Currently includes: 
- Custom Scrap Item API
- Custom Enemy API (Untested)
- Network Prefab API
