# LethalLib  
**A library for adding new content to Lethal Company, mainly for personal use.**
  
Currently includes:   
- Custom Scrap Item API  
- Custom Shop Item API  
- Unlockables API  
- Map hazards API
- Dungeon API
- Custom Enemy API  
- Network Prefab API  

# Recent Changes 
  
- Added full custom dungeon support for Dungeon API  
	- Requires scriptable objects / prefabs which are set-up correct.  