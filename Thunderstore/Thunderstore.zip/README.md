# LethalLib  
**A library for adding new content to Lethal Company, mainly for personal use.**
  
Currently includes: 
- Custom Scrap Item API
- Custom Shop Item API
- Custom Enemy API (Untested)
- Network Prefab API

# Recent Changes 
   
- Changed up some function calls (Breaking change)
- Better logging